#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cctype>
#include <algorithm>
#include "Translator.h"
using namespace std;

Translator::Translator(const char dict_file[])
{
    string eng;
    string elf;
    fstream str;

    //open dict_file as input
    str.open(dict_file, ios::in);
    while(str.fail())
    {
      char filename[25];
      strcpy(filename, dict_file);
      cout << "Invalid dictionary filename - " << dict_file << endl << endl;
      cout << "Please enter a valid filename and press enter" << endl;
      cin >> filename;
      str.open(filename, ios::in);
    }

    do  {
            str >> eng;  //get next into eng
            str >> elf;  //get next into elf
            eng_elf[eng] = elf; // input a new index/value pair in the eng_elf map
            elf_eng[elf] = eng; // input a new index/value pair in the elf_eng map
    }   while (!str.eof()); // loop while not at the end of dictionary file

    str.close();
}

void Translator::toElvish(char out_s[], const char s[])
{
    // declare string variables to hold the english and elvish words and sentences
    string engword, elfword, engsent, elfsent="";   // elfsent initialised to empty string as it has to be added to
    engsent = s;             // copy the english line passed in the parameter into engsent
    stringstream sstream1(engsent);  // declare the string stream ss1 to get words from english line

    while(sstream1 >> engword)         // loop while successfully puts the next word from the engsent into engword
    {
        elfword = translate(engword, true);    // translate the word, bool true means its an english word
        elfsent = elfsent + elfword + " ";          // append the translated word to the end of elfsent + space
    }

    strcpy(out_s, elfsent.c_str());     // Copies the string 'elfsent' into the array out_s
}

void Translator::toEnglish(char out_s[],const char s[])
{
    // declare string variables to hold the english and elvish words and sentences
    string elfword, engword, elfsent, engsent="";   // engsent initialised to empty string as it has to be added to
    elfsent = s;             // copy the elvish line passed in the parameter into elfsent
    stringstream sstream2(elfsent);  // declare the string stream ss1 to get words from elvish line

    while(sstream2 >> elfword)         // loop while successfully puts the next word from elfsent into elfword
    {
        engword = translate(elfword, false);       // translate the word, bool true means its an elvish word
        engsent = engsent + engword + " ";          // append the translated word to the end of engsent + space
    }

    strcpy(out_s, engsent.c_str());     // Copies the string engsent into the array out_s
}

string Translator::translate(string word, bool english)
{
    string translation; // declare the string 'translation' to hold the translated word
    string beforepunct = "";
    string endpunct = "";  // declare the string punct to hold the punctuation characters at the end of a word
    bool capital = false;// declare a bool to define if a word has a capital letter at the start or not

    if ( word[0]=='*')  // if the string has an asterisk at start
    {
        if (word[word.size()-1] == '*') //if it has one at the end too
        {
            translation = word.substr(1,word.size()-2);  //translation = word with first and last chars removed
            return translation;         //return the word without the asterisks
        }

        else if (word[word.size()-2 == '*'])    // if the second last char is an asterisk, happens when a punctuation mark e.g. a comma after the word
        {
            char punct = word[word.size() - 1];
            translation = word.substr(1,word.size()-3) + punct;
        }
    }

    else if (word == "-")   // handles lone dashes
        return "*" + word + "*";

    else if(english) // if the word to be translated is english
    {
        //remove punctuation and store in the variable beforepunct and endpunct
        while(!isalpha(word[0])) // while the first letter in the word is not a alphabetical character, ie some punctuation mark
        {
            beforepunct = beforepunct + word[0];    // store the punctuation mark(s) in beforepunct.
            word = word.substr(1, word.size());   // erase the first character in the string
        }

        while(!isalpha(word[word.size()-1])) // while the last letter in the word is not a alphabetical character
        {
            endpunct = word[word.size()-1] + endpunct;    //store the punctuation mark(s) in endpunct
            word = word.substr(0, word.size()-1);   // erase the last character in the string
        }

        if( word[0]>='A' && word[0]<='Z')   // if the first letter is a capital
            capital = true;                 // evalueate capital to true

        std::transform(word.begin(), word.end(), word.begin(), ::tolower); // convert all the letters to lowercase

        map<string,string>::iterator it = eng_elf.find(word);   //declare the iterator 'it' which searches for the word
                                                                //and if present stores the pair in it
        if(it != eng_elf.end())         // if the word is present
        {
            if (!capital)       // if the word was not capitalised
                translation = beforepunct + it->second + endpunct;  // store the translation in 'translation
                                                                    // and add the punctuation back to the word

            else                // if the word should be capitalised
            {
                translation = it->second;   //
                translation[0] = toupper(translation[0]);
                translation = beforepunct + translation + endpunct;  // add punctuation back and capitalise the first letter
            }

            return translation;
        }

        else    // if the word not in the dictionary
        {
            if (capital)
                word[0] = toupper(word[0]);   // uppercase the first letter in the translation
            translation = "*" + beforepunct + word + "*" + endpunct;     // encase the translation in *sdf*
        }
        return translation;
    }

    else if (!english)  // if the word to be translation is elfish
    {
        //remove punctuation and store in the variable beforepunct and endpunct
        while(!isalpha(word[0])) // while the first letter in the word is not a alphabetical character, ie some punctuation mark
        {
            beforepunct = beforepunct + word[0];    // store the punctuation mark(s) in beforepunct.
            word = word.substr(1, word.size());   // erase the first character in the string
        }

        while(!isalpha(word[word.size()-1])) // while the last letter in the word is not a alphabetical character
        {
            endpunct = word[word.size()-1] + endpunct;    //store the punctuation mark(s) in endpunct
            word = word.substr(0, word.size()-1);   // erase the last character in the string
        }

        if( word[0]>='A' && word[0]<='Z')   // if the first letter is a capital
            capital = true;

        std::transform(word.begin(), word.end(), word.begin(), ::tolower); // convert all the letters to lowercase

        map<string,string>::iterator it = elf_eng.find(word);   //declare the iterator 'it' which searches for the word
                                                                //and if present stores the pair in 'it'
        if(it != elf_eng.end())     // if the word is present
        {
            if (!capital)       // if the word was not capitalised
                translation = beforepunct + it->second + endpunct;  // store the translation in 'translation
                                                                        // and add back on the punctuation to the end of the word

            else // if the word should be capitalised
            {
                    translation = it->second;
                    translation[0] = toupper(translation[0]);
                    translation = beforepunct + translation + endpunct;  // add punctuation back and capitalise the first letter
            }
        }
        return translation;
    }

    else    // if the word not in the dictionary
    {
        if (capital)
            word[0] = toupper(word[0]);   // uppercase the first letter in the translation
        translation = beforepunct + "*" + word + "*" + endpunct;     // encase the translation in *sdf*
        return translation;
    }

    return translation;
}
