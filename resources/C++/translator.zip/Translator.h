#ifndef TRANSLATOR_H_INCLUDED
#define TRANSLATOR_H_INCLUDED
#include<string>
#include <iostream>
#include <iomanip>
#include <map>
const int MAX_NUM_WORDS=2000;
const int MAX_WORD_LEN=50;

class Translator
{
    public:
    Translator(const char dict_file[]);
    void toElvish(char translated_line[], const char original_line[]);
    void toEnglish(char translated_line[],const char original_line[]);
    std::string translate(std::string word, bool english);

    private:
    std::map<std::string, std::string> eng_elf;
    std::map<std::string, std::string> elf_eng;
};

#endif // TRANSLATOR_H_INCLUDED
